/*
    02_transform_cte.sql
    ---------------------
    Ad-hoc / exploratory version of the transform logic, showing the CTEs
    on their own before they get wrapped into the stored procedure in
    03_stored_procedure.sql. Useful for testing transform logic in SSMS
    before deploying it.
*/

-- CTE 1: de-duplicate staged records, keeping the most recently loaded
-- version of each PersistentId (handles re-runs / re-extracts safely).
WITH DedupedRecords AS (
    SELECT
        PersistentId,
        Category,
        StreetName,
        Latitude,
        Longitude,
        OutcomeCategory,
        ReportedMonth,
        ROW_NUMBER() OVER (
            PARTITION BY COALESCE(NULLIF(PersistentId, ''), CAST(RecordId AS NVARCHAR(20)))
            ORDER BY LoadedDateTime DESC
        ) AS RowNum
    FROM Staging.CrimeReports
),

-- CTE 2: apply cleaning/enrichment rules on top of the deduplicated set
CleanedRecords AS (
    SELECT
        PersistentId,
        REPLACE(Category, '-', ' ') AS Category,
        StreetName,
        Latitude,
        Longitude,
        CASE WHEN Latitude IS NULL THEN 0 ELSE 1 END AS HasLocation,
        OutcomeCategory,
        CASE WHEN OutcomeCategory IS NULL THEN 0 ELSE 1 END AS HasOutcome,
        ReportedMonth
    FROM DedupedRecords
    WHERE RowNum = 1
)

-- Preview the transformed output before it's merged into Reporting.CrimeReports
SELECT * FROM CleanedRecords
ORDER BY Category, StreetName;

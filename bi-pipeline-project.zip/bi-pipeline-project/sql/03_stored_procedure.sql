/*
    03_stored_procedure.sql
    ------------------------
    Production procedure: called by the SQL Agent job that runs after the
    Python extract/load step lands new data in Staging.CrimeReports.

    Combines: CTEs for cleaning, MERGE for the combined insert/update load,
    and a data quality log write so every run is auditable.
*/

CREATE OR ALTER PROCEDURE Reporting.usp_LoadCrimeReports
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @TotalIn INT, @MissingLocation INT, @MissingOutcome INT,
            @Duplicates INT, @MissingCategory INT;

    -- Capture data quality metrics before transformation (gap analysis)
    SELECT
        @TotalIn = COUNT(*),
        @MissingLocation = SUM(CASE WHEN Latitude IS NULL THEN 1 ELSE 0 END),
        @MissingOutcome = SUM(CASE WHEN OutcomeCategory IS NULL THEN 1 ELSE 0 END),
        @MissingCategory = SUM(CASE WHEN Category IS NULL THEN 1 ELSE 0 END)
    FROM Staging.CrimeReports;

    SELECT @Duplicates = COUNT(*) - COUNT(DISTINCT PersistentId)
    FROM Staging.CrimeReports
    WHERE PersistentId IS NOT NULL AND PersistentId <> '';

    -- CTE 1: de-duplicate, keeping the most recently loaded version of each record
    WITH DedupedRecords AS (
        SELECT
            PersistentId,
            Category,
            StreetName,
            Latitude,
            Longitude,
            OutcomeCategory,
            ReportedMonth,
            ROW_NUMBER() OVER (
                PARTITION BY COALESCE(NULLIF(PersistentId, ''), CAST(RecordId AS NVARCHAR(20)))
                ORDER BY LoadedDateTime DESC
            ) AS RowNum
        FROM Staging.CrimeReports
    ),

    -- CTE 2: apply cleaning and enrichment rules
    CleanedRecords AS (
        SELECT
            PersistentId,
            REPLACE(Category, '-', ' ') AS Category,
            StreetName,
            Latitude,
            Longitude,
            CASE WHEN Latitude IS NULL THEN 0 ELSE 1 END AS HasLocation,
            OutcomeCategory,
            CASE WHEN OutcomeCategory IS NULL THEN 0 ELSE 1 END AS HasOutcome,
            ReportedMonth
        FROM DedupedRecords
        WHERE RowNum = 1
    )

    -- MERGE: combined insert (new records) / update (existing records) load
    MERGE Reporting.CrimeReports AS target
    USING CleanedRecords AS source
        ON target.PersistentId = source.PersistentId
        AND target.PersistentId IS NOT NULL
    WHEN MATCHED THEN
        UPDATE SET
            Category = source.Category,
            StreetName = source.StreetName,
            Latitude = source.Latitude,
            Longitude = source.Longitude,
            HasLocation = source.HasLocation,
            OutcomeCategory = source.OutcomeCategory,
            HasOutcome = source.HasOutcome,
            ReportedMonth = source.ReportedMonth,
            LastUpdated = SYSDATETIME()
    WHEN NOT MATCHED THEN
        INSERT (PersistentId, Category, StreetName, Latitude, Longitude,
                HasLocation, OutcomeCategory, HasOutcome, ReportedMonth)
        VALUES (source.PersistentId, source.Category, source.StreetName,
                source.Latitude, source.Longitude, source.HasLocation,
                source.OutcomeCategory, source.HasOutcome, source.ReportedMonth);

    -- Log the data quality findings for this run (auditable history)
    INSERT INTO Reporting.DataQualityLog
        (TotalRecordsIn, MissingLocationCount, MissingOutcomeCount,
         DuplicateRecordCount, MissingCategoryCount)
    VALUES
        (@TotalIn, @MissingLocation, @MissingOutcome, @Duplicates, @MissingCategory);

    -- Clear staging once successfully merged
    TRUNCATE TABLE Staging.CrimeReports;

    PRINT CONCAT('Load complete. Processed ', @TotalIn, ' staged records.');
END;
GO

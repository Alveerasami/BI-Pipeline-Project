/*
    01_schema.sql
    -------------
    Warehouse schema for SQL Server (T-SQL).

    This is the production target for the pipeline: extract.py / transform.py
    load data into a Staging schema; this script + 02_transform_cte.sql +
    03_stored_procedure.sql then move it into a clean Reporting schema.

    Demonstrates basic Data Warehouse principles: a raw/staging layer kept
    separate from a cleaned/reporting layer, so source data is never
    overwritten and transformations are repeatable and auditable.
*/

CREATE SCHEMA Staging;
GO

CREATE SCHEMA Reporting;
GO

-- Raw landing table: shape mirrors the source API/system as closely as
-- possible, with minimal transformation, so we always have an auditable
-- copy of what was extracted.
CREATE TABLE Staging.CrimeReports (
    RecordId            INT             NOT NULL,
    PersistentId         NVARCHAR(64)    NULL,
    Category            NVARCHAR(100)   NULL,
    StreetName           NVARCHAR(200)   NULL,
    Latitude             DECIMAL(9,6)    NULL,
    Longitude            DECIMAL(9,6)    NULL,
    OutcomeCategory       NVARCHAR(200)   NULL,
    OutcomeDate           NVARCHAR(10)    NULL,
    ReportedMonth         NVARCHAR(10)    NULL,
    LoadedDateTime        DATETIME2       NOT NULL DEFAULT SYSDATETIME()
);
GO

-- Clean, reporting-ready table: deduplicated, typed, and enriched with
-- flags used across dashboards and statutory returns.
CREATE TABLE Reporting.CrimeReports (
    CrimeReportKey       INT IDENTITY(1,1) PRIMARY KEY,
    PersistentId          NVARCHAR(64)    NULL,
    Category             NVARCHAR(100)   NOT NULL,
    StreetName            NVARCHAR(200)   NULL,
    Latitude              DECIMAL(9,6)    NULL,
    Longitude             DECIMAL(9,6)    NULL,
    HasLocation            BIT             NOT NULL,
    OutcomeCategory        NVARCHAR(200)   NULL,
    HasOutcome              BIT             NOT NULL,
    ReportedMonth           NVARCHAR(10)    NOT NULL,
    LastUpdated             DATETIME2       NOT NULL DEFAULT SYSDATETIME()
);
GO

-- Data quality log: every pipeline run writes a row here, giving an
-- auditable history of gap analysis / data quality findings over time -
-- useful evidence for inspections and service improvement reporting.
CREATE TABLE Reporting.DataQualityLog (
    LogId                 INT IDENTITY(1,1) PRIMARY KEY,
    RunDateTime            DATETIME2       NOT NULL DEFAULT SYSDATETIME(),
    TotalRecordsIn          INT             NOT NULL,
    MissingLocationCount     INT             NOT NULL,
    MissingOutcomeCount       INT             NOT NULL,
    DuplicateRecordCount       INT             NOT NULL,
    MissingCategoryCount        INT             NOT NULL
);
GO

/*
    04_reports.sql
    ---------------
    Example reporting queries run against Reporting.CrimeReports,
    demonstrating the different query structures and presentation types
    referenced in the job spec: simple, combined, merged, table, crosstab.
*/

-- 1) SIMPLE QUERY -> TABLE presentation
SELECT
    Category,
    StreetName,
    OutcomeCategory,
    ReportedMonth
FROM Reporting.CrimeReports
ORDER BY Category, StreetName;
GO

-- 2) COMBINED QUERY -> summary table (two aggregates combined via CTE + JOIN)
WITH Volume AS (
    SELECT Category, COUNT(*) AS TotalIncidents
    FROM Reporting.CrimeReports
    GROUP BY Category
),
Outcomes AS (
    SELECT Category, COUNT(*) AS IncidentsWithOutcome
    FROM Reporting.CrimeReports
    WHERE HasOutcome = 1
    GROUP BY Category
)
SELECT
    v.Category,
    v.TotalIncidents,
    ISNULL(o.IncidentsWithOutcome, 0) AS IncidentsWithOutcome,
    CAST(100.0 * ISNULL(o.IncidentsWithOutcome, 0) / v.TotalIncidents AS DECIMAL(5,1)) AS OutcomeRatePct
FROM Volume v
LEFT JOIN Outcomes o ON v.Category = o.Category
ORDER BY v.TotalIncidents DESC;
GO

-- 3) MERGED QUERY -> CROSSTAB presentation using PIVOT
-- (Category across the top, Street down the side - typical performance
-- dashboard crosstab / matrix view)
SELECT StreetName,
    ISNULL([Burglary], 0)              AS Burglary,
    ISNULL([Drugs], 0)                 AS Drugs,
    ISNULL([Vehicle Crime], 0)         AS VehicleCrime,
    ISNULL([Violent Crime], 0)         AS ViolentCrime,
    ISNULL([Anti Social Behaviour], 0) AS AntiSocialBehaviour
FROM (
    SELECT StreetName, Category FROM Reporting.CrimeReports
) AS SourceTable
PIVOT (
    COUNT(Category)
    FOR Category IN ([Burglary], [Drugs], [Vehicle Crime], [Violent Crime], [Anti Social Behaviour])
) AS PivotTable
ORDER BY StreetName;
GO

-- 4) CHART-ready aggregate (feeds a bar/column chart in Power BI / SSRS)
SELECT Category, COUNT(*) AS IncidentCount
FROM Reporting.CrimeReports
GROUP BY Category
ORDER BY IncidentCount DESC;
GO

-- 5) Data quality trend, for service improvement / inspection evidence
SELECT
    RunDateTime,
    TotalRecordsIn,
    MissingLocationCount,
    MissingOutcomeCount,
    DuplicateRecordCount,
    CAST(100.0 * MissingLocationCount / NULLIF(TotalRecordsIn, 0) AS DECIMAL(5,1)) AS MissingLocationPct
FROM Reporting.DataQualityLog
ORDER BY RunDateTime DESC;
GO
